
## Correr Proyecto

Para correr este proyecto debe tener Python instalado, el programa fue testeado en windows 10 64bits usando visual studio code con python 3.9.5, con la carpeta abierta en terminal corra el siguiente comando:

pip install virtualenv

En terminal corra el siguiente comando el cual creara un entorno virtual:

virtualenv env

Para mac/linux debera usar el siguiente comando( en caso de usar windows omita este paso):

source env/bin/active

Luego instale las dependencias del proyecto (requirements.txt) usando el siguiente comando en terminal:

pip install -r requirements.txt

Ahora podra correr este proyecto usando el siguiente comando y abriendo la direccion correspondiento al ejecturar el proyecto:

python manage.py runserver

## Proyecto creado en Python 3 usando django y bootstrap. Gracias por su atencion